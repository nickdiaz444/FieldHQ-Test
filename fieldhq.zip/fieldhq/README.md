# FieldHQ — League Management Platform

A complete league management web app. Deploy to Vercel in under 5 minutes.

## Pages

| File | URL | Description |
|------|-----|-------------|
| `index.html` | `/` | Admin dashboard (your control panel) |
| `public.html` | `/public.html` | Public league page (share with parents/players) |
| `register.html` | `/register.html` | Player self-registration form |

## Deploy to Vercel (Step by Step)

1. Go to [vercel.com](https://vercel.com) and create a free account
2. Click **"Add New Project"**
3. Click **"Upload"** (you don't need GitHub for this)
4. Drag the entire `fieldhq` folder into the upload area
5. Click **Deploy**
6. Done — Vercel gives you a live URL like `https://fieldhq-abc123.vercel.app`

That's it. No build step, no configuration needed.

## File Structure

```
fieldhq/
├── index.html          ← Admin app
├── public.html         ← Public league page
├── register.html       ← Player registration
├── vercel.json         ← Vercel routing config
├── README.md
└── src/
    ├── css/
    │   └── main.css    ← All styles
    └── js/
        └── data.js     ← All data/state logic
```

## Adding a Real Database (Supabase)

Right now data saves to the browser's localStorage. To make data persist
across devices and users, connect Supabase:

1. Create a free account at [supabase.com](https://supabase.com)
2. Create a new project
3. In `src/js/data.js`, replace the `save()` and `_load()` methods
   with Supabase calls (Claude can write this for you)
4. Add your Supabase URL and anon key to the top of `data.js`

## Adding Payments (Stripe)

For registration fees:
1. Create a Stripe account at [stripe.com](https://stripe.com)
2. Add a Stripe Checkout call in `register.html` before `submitRegistration()`
3. Claude can write the full Stripe integration for you

## Customizing

- **Colors/fonts**: Edit CSS variables at the top of `src/css/main.css`
- **Default data**: Edit the `defaults` object in `src/js/data.js`
- **League name**: Change in the admin under ⚙ League Settings
